/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class IssuebookTest {
    
    public IssuebookTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of solve method, of class Issuebook.
     */
    @Test
    public void testSolve() {
        System.out.println("solve");
        Issuebook instance = new Issuebook();
        instance.solve();
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of Reset method, of class Issuebook.
     */
    @Test
    public void testReset() {
        System.out.println("Reset");
        String ID = "";
        String Name = "";
        String Author = "";
        String Category = "";
        String Price = "";
        Issuebook instance = new Issuebook();
        boolean expResult = false;
        boolean result = instance.Reset(ID, Name, Author, Category, Price);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of delete method, of class Issuebook.
     */
    @Test
    public void testDelete() {
        System.out.println("delete");
        String ID = "";
        Issuebook instance = new Issuebook();
        boolean expResult = false;
        boolean result = instance.delete(ID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of addintobook method, of class Issuebook.
     */
    @Test
    public void testAddintobook() {
        System.out.println("addintobook");
        String ID = "";
        String book_name = "";
        String book_auth = "";
        String category = "";
        String pice = "";
        Issuebook instance = new Issuebook();
        boolean expResult = false;
        boolean result = instance.addintobook(ID, book_name, book_auth, category, pice);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of showdata method, of class Issuebook.
     */
    @Test
    public void testShowdata() {
        System.out.println("showdata");
        Issuebook instance = new Issuebook();
        boolean expResult = false;
        boolean result = instance.showdata();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of updaterecord method, of class Issuebook.
     */
    @Test
    public void testUpdaterecord() {
        System.out.println("updaterecord");
        String name = "";
        String ID = "";
        Issuebook instance = new Issuebook();
        boolean expResult = false;
        boolean result = instance.updaterecord(name, ID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Issuebook.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Issuebook.main(args);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 abstract class ClassFactory {
    public abstract Factory_interface getObject(String ObjectType);
    
}
public class Factory_Class {
     public Factory_interface getObject(String ObjectType){
        if(ObjectType == null)
    {
        return null;
    }
    if(ObjectType.equalsIgnoreCase("Account Details")){
        return new ACCOUNT_DETAILS();
    } 
    else if(ObjectType.equalsIgnoreCase("ISSUE"))
    {
        return new ISSUE();
    } 

    return null;
    }
}

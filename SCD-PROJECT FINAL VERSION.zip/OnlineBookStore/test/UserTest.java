/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class UserTest {
    
    public UserTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of solve method, of class User.
     */
    @Test
    public void testSolve() {
        System.out.println("solve");
        User instance = new User();
        instance.solve();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of Reset method, of class User.
     */
    @Test
    public void testReset() {
        System.out.println("Reset");
        String ID = "";
        String Name = "";
        String Email = "";
        String Contact = "";
        User instance = new User();
        boolean expResult = true;
        boolean result = instance.Reset(ID, Name, Email, Contact);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of delu method, of class User.
     */
    @Test
    public void testDelu() {
        System.out.println("delu");
        String ID = "";
        User instance = new User();
        boolean expResult = false;
        boolean result = instance.delu(ID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of showdata method, of class User.
     */
    @Test
//    public void testShowdata() {
//        System.out.println("showdata");
//        User instance = new User();
//        boolean expResult = false;
//        boolean result = instance.showdata();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//       // fail("The test case is a prototype.");
//    }

    /**
     * Test of updaterecord method, of class User.
     */
   // @Test
    public void testUpdaterecord() {
        System.out.println("updaterecord");
        String nam = "";
        String ID = "";
        User instance = new User();
        boolean expResult = true;
        boolean result = instance.updaterecord(nam, ID);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class User.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        User.main(args);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}

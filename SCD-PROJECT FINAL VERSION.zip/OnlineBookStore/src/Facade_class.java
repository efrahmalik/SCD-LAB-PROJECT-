/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class Facade_class {
    
    private Facade_interface ib;
    private Facade_interface user;

    public Facade_class() {
       ib = new Issuebook();
       user = new User();
    }
    
    public void issuebook(){
        ib.solve();
    }
    
    public void User(){
        user.solve();
    }
}

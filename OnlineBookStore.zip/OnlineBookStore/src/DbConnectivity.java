/*
 
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;  

public class DbConnectivity {
    
    public static void main(String args[])
    {  
       // String x="integrated Security=true";
try{  
Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  

//here sonoo is database name, root is username and password 

    try (Connection con = DriverManager.getConnection(  
            "jdbc:sqlserver://DESKTOP-EM6BMB7\\SQLEXPRESS;databaseName=onlinebookstore;integratedSecurity=true")) {
        //here sonoo is database name, root is username and password
        Statement stmt=con.createStatement();
        stmt.executeUpdate("INSERT into Registration VALUES ('laiba21', '123','laiba@gmail.com', '03315127')");
        ResultSet rs=stmt.executeQuery("select * from Registration");
        while(rs.next())
            System.out.println(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+" "+rs.getString(4));  
    }
} catch(Exception e){ System.out.println(e);
}  
}  
}

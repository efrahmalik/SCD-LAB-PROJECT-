//interface class 
public interface Factory_interface 
{
    //this method will be implemented by the concrete classes
    public void operation();
    
}

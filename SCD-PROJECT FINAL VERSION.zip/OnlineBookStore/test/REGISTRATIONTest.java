

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class REGISTRATIONTest {
    
    public REGISTRATIONTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of run method, of class REGISTRATION.
     */
    @Test
    public void testRun() {
        System.out.println("run");
        REGISTRATION instance = new REGISTRATION("");
        instance.run();
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of add method, of class REGISTRATION.
     */
    @Test
    public void testAdd() {
        System.out.println("add");
        String Username = "Asma";
        String Password = "Asma1234";
        String email = "asma@gmail.com";
        String contact = "0-1742819264";
        REGISTRATION instance = new REGISTRATION("");
        boolean expResult = true;
        boolean result = instance.add(Username, Password, email, contact);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
      //  fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class REGISTRATION.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        REGISTRATION.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}

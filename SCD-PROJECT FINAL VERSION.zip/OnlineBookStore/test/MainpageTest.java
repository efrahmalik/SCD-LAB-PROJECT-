/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class MainpageTest {
    
    public MainpageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of run method, of class Mainpage.
     */
    @Test
    public void testRun() {
        System.out.println("run");
        Mainpage instance = new Mainpage("");
        instance.run();
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of retrieveCurrentUser method, of class Mainpage.
     */
//    @Test
//    public void testRetrieveCurrentUser() {
//        System.out.println("retrieveCurrentUser");
//        Mainpage instance =new Mainpage("");
//        String expResult = "null";
//        String result = instance.retrieveCurrentUser();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//      //  fail("The test case is a prototype.");
//    }

    /**
     * Test of main method, of class Mainpage.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Mainpage.main(args);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }
    
}

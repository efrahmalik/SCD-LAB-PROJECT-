/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Administrator
 */
public class LOGINTest {
    
    public LOGINTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of login method, of class LOGIN.
     */
    @Test
    public void testLogin() {
        System.out.println("login");
        LOGIN instance = new LOGIN("");
        boolean expResult = false;
        boolean result = instance.login();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of run method, of class LOGIN.
     */
    @Test
    public void testRun() {
        System.out.println("run");
        LOGIN instance =new LOGIN("");
        instance.run();
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of admin method, of class LOGIN.
     */
    @Test
    public void testAdmin() {
        System.out.println("admin");
        String username = "Admin";
        String password = "admin";
        LOGIN instance = new LOGIN("");
        boolean expResult = true;
        boolean result = instance.admin(username, password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class LOGIN.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        LOGIN.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
